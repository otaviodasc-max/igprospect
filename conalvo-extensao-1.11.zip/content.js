// Conalvo 1.11 — painel no Instagram. O ambiente vem do config.js (carregado antes
// deste arquivo pelo manifest): em staging aparece o selo "DEV".
// Abas: Perfil (status no topo, adicionar com "Seguido" marcado, chamado,
// follow-up, respondeu, "Enviou contato" + CRM), Hoje (resumo calculado no
// banco), Leads (busca e filtros paginados), Contatos e Config.
// • Login (sem "quem é você"); só a equipe escolhida; nada da equipe inteira
//   é baixado: toda lista é paginada no servidor (25 por vez).
// • Cada ação leva um id único; em falha de rede reenviamos o MESMO id e o
//   banco devolve o resultado guardado (nunca duplica).
// • Respostas de outra equipe/perfil/filtro que chegam atrasadas são descartadas.
// • Sucesso só aparece depois de o servidor confirmar (inclusive o CRM).
(() => {
  if (window.__CONALVO_111__) return; window.__CONALVO_111__ = true;
  const AMB = ((self.CONALVO_CFG || {}).AMBIENTE) === 'producao' ? 'producao' : 'staging';
  const SELO = AMB === 'staging' ? '<span class="dev">DEV</span>' : '';

  // ── Detecção de nome e @ (copiada da extensão 1.10.4) ──
  // Única correção: um nome que só difere do @ em maiúsculas ("NASA" no perfil
  // @nasa) é o nome de verdade. A 1.10.4 descartava e acabava pegando a bio.
  const RESERVED = new Set(['explore','reel','reels','p','tv','stories','accounts','direct','notifications','ar','challenges','audio','shop','about','privacy','help','']);
  const GENERIC_NAMES = new Set(['mensagens','messages','direct','solicitações','solicitacoes','requests','inbox','chats','conversas','não seguidores','nao seguidores','not following you back','seguidores','digital creator','personal blog','public figure','blogger','este perfil é privado','esta conta é privada','essa conta é privada','perfil privado','this account is private','conta privada']);
  const BAD_NAME_RE=/^(seguir|follow|following|seguindo|message|mensagem|enviar mensagem|publicaç|posts?|seguidor|follower|não segu|nao segu|not follow|verificad|editar|ver tudo|sugest|cancelar|nota|stories?|destaque|digital creator|personal blog|public figure|blogger|criador\(a\)|perfil.{0,3}privad|account is private|conta privada|remover|bloquear|denunciar|silenciar|restringir)/i;
  function isBadName(t){ const tl=(t||'').trim().toLowerCase(); if(!tl) return true; if(GENERIC_NAMES.has(tl)) return true; return BAD_NAME_RE.test(tl); }
  function nameFromProfile(uLow, uOrig){
    try{
      const root=document.querySelector('main')||document.body;
      for(const el of root.querySelectorAll('h1,h2,span,div')){
        if(el.children.length>0) continue;
        const t=(el.textContent||'').trim();
        if(t.length<2||t.length>60) continue;
        const tl=t.toLowerCase();
        if(tl==='@'+uLow) continue;
        if(tl===uLow){ if(t!==uOrig && t!==uLow && /[A-ZÀ-Ý]/.test(t)) return t; continue; }   // "NASA" ≠ "nasa": é o nome
        if(t.startsWith('@')) continue;
        if(/instagram/i.test(t)) continue;
        if(/^[\d.,\s]+$/.test(t)) continue;
        if(/\d+\s*(post|seguidor|follower|seguindo|mil|mi\b)/i.test(t)) continue;
        if(!/[A-Za-zÀ-ÿ]/.test(t)) continue;
        if(isBadName(t)) continue;
        return t;
      }
    }catch(_){}
    return '';
  }
  function findRealName(username){
    const uLow=username.toLowerCase();
    const dom=nameFromProfile(uLow, username);
    if(dom && (dom.toLowerCase()!==uLow || dom!==username)) return dom;
    const parse=(s)=>{ if(!s) return ''; const mm=s.match(/^(.+?)\s*\(@([A-Za-z0-9._]+)\)/); if(!mm||mm[2].toLowerCase()!==uLow) return ''; const nm=mm[1].trim(); return (nm&&!isBadName(nm)&&nm.toLowerCase()!=='instagram'&&(nm.toLowerCase()!==uLow||(nm!==username&&/[A-ZÀ-Ý]/.test(nm))))?nm:''; };
    try{ const og=document.querySelector('meta[property="og:title"]'); const n=parse(og&&og.content); if(n) return n; }catch(_){}
    const n2=parse(document.title); if(n2) return n2;
    return username;
  }
  const perfilDaUrl = href => { const m=href.match(/^https?:\/\/(?:www\.)?instagram\.com\/([a-zA-Z0-9._]+)\/?(?:\?.*)?$/); return (m&&!RESERVED.has(m[1]))?m[1]:null; };

  // ── Comunicação com o service worker ──
  const enviar = msg => new Promise(ok => chrome.runtime.sendMessage(msg, r => ok(r || { ok:false, erro:(chrome.runtime.lastError&&chrome.runtime.lastError.message)||'Extensão sem resposta', codigo:'rede' })));
  const rpc = async (fn, args) => { const r = await enviar({ tipo:'rpc', fn, args }); if(!r.ok){ const e=new Error(r.erro); e.codigo=r.codigo; throw e; } return r.dados; };
  // Reenvia com os MESMOS argumentos (mesmo client_id) em falha de rede: o banco devolve o resultado guardado.
  async function rpcSeguro(fn, args){
    let ultimo;
    for(let i=0;i<3;i++){ try{ return await rpc(fn, args); }catch(e){ ultimo=e; if(e.codigo!=='rede') throw e; await new Promise(r=>setTimeout(r, 400*(i+1))); } }
    throw ultimo;
  }
  const novoId = () => (crypto.randomUUID ? crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const r=Math.random()*16|0;return (c==='x'?r:(r&3|8)).toString(16);}));

  // ── Estado (tudo por equipe; trocar de equipe zera) ──
  const vazioLista = () => ({ itens:[], proximo:null, carregando:false, carregado:false });
  const S = { usuario:null, equipe:null, equipes:null, ctx:null, aba:'perfil', perfil:null, lead:undefined, ocupado:'', msg:null, tempos:{}, seguido:true, minimizado:false, href:'',
    telefone:null,   // { leadId, valor } — formulário "Enviou contato" aberto
    hoje:{ periodo:'hoje', meus:false, dados:null, carregando:false },
    leads:{ busca:'', etapa:'', nota:'', meus:false, ordem:'recentes', aberto:null, ...vazioLista() },
    contatos:{ busca:'', ...vazioLista() } };
  const seq = { perfil:0, hoje:0, leads:0, contatos:0 };
  const eqId = () => S.equipe && S.equipe.id;
  const fmtDia = iso => { if(!iso) return ''; try{ return new Date(iso).toLocaleString('pt-BR',{ timeZone:'America/Sao_Paulo', day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit' }); }catch(_){ return ''; } };
  const fmtData = iso => { if(!iso) return ''; try{ return new Date(iso).toLocaleDateString('pt-BR',{ timeZone:'America/Sao_Paulo', day:'2-digit', month:'2-digit', year:'2-digit' }); }catch(_){ return ''; } };
  const diaBR = (d=new Date()) => new Intl.DateTimeFormat('en-CA',{ timeZone:'America/Sao_Paulo', year:'numeric', month:'2-digit', day:'2-digit' }).format(d);
  const esc = s => String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmtTel = t => { const d=String(t||'').replace(/\D/g,''); const n=d.length>11&&d.startsWith('55')?d.slice(2):d; if(n.length===11) return `(${n.slice(0,2)}) ${n.slice(2,7)}-${n.slice(7)}`; if(n.length===10) return `(${n.slice(0,2)}) ${n.slice(2,6)}-${n.slice(6)}`; return t||''; };
  const linkWhats = t => { const d=String(t||'').replace(/\D/g,''); return 'https://wa.me/' + (d.length<=11 ? '55'+d : d); };
  const pipelineDo = lead => { const ps=(S.ctx&&S.ctx.pipelines)||[]; return ps.find(p=>p.id===(lead&&lead.pipeline_id)) || ps.find(p=>p.is_default) || ps[0] || null; };
  const etapasPadrao = () => { const p=pipelineDo(null); return p?[...p.stages].sort((a,b)=>a.order-b.order):[]; };
  const chip = e => e ? `<span class="chip" style="--c:${esc(e.color||'#64748B')}"><i></i>${esc(e.label)}</span>` : '';
  const crmAtivo = () => !!(S.ctx && S.ctx.crm && S.ctx.crm.ativo);
  // Etapa do lead + setinha: troca a etapa ali mesmo, sem abrir o lead.
  // "Enviou contato" abre o campo do telefone (fluxo próprio, com CRM); as regras
  // (ex.: não pular o chamado) são do banco (ext2_mudar_etapa).
  function chipEtapa(L){
    if(!L||!L.etapa) return chip(L&&L.etapa);
    const aberto=S.menuEtapa===L.id;
    return `<span class="etp">${chip(L.etapa)}<button class="seta ${aberto?'on':''}" data-a="etapa_menu" data-lead="${esc(L.id)}" title="Trocar etapa" aria-label="Trocar etapa" ${S.ocupado?'disabled':''}>▾</button>${aberto?menuEtapas(L):''}</span>`;
  }
  function menuEtapas(L){
    const pl=pipelineDo(L), est=pl?[...pl.stages].sort((a,b)=>a.order-b.order):[];
    return `<div class="menu" role="menu">${est.map(e=>{ const atual=e.key===L.status, contato=pl&&e.key===pl.contato_key;
      return `<button role="menuitem" data-a="etapa_escolher" data-lead="${esc(L.id)}" data-k="${esc(e.key)}" style="--c:${esc(e.color||'#64748B')}" ${atual?'disabled':''}><i></i>${esc(e.label)}${atual?'<small>atual</small>':contato?'<small>pede telefone</small>':''}</button>`; }).join('')}</div>`;
  }

  // ── Painel (Shadow DOM) ──
  const host = document.createElement('div'); host.id='conalvo-dev-host';
  const raiz = host.attachShadow({ mode:'open' });
  const LOGO = chrome.runtime.getURL('logo.png');
  raiz.innerHTML = `<style>
    :host{all:initial}
    .p{color-scheme:light;position:fixed;top:72px;right:16px;width:360px;max-height:calc(100vh - 92px);display:flex;flex-direction:column;z-index:2147483646;font:13px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',Inter,Roboto,sans-serif;color:#0B0B0C;background:#fff;border-radius:16px;box-shadow:0 18px 50px rgba(0,0,0,.22),0 0 0 1px rgba(184,137,43,.35);overflow:hidden}
    .p.min{width:auto}
    .hd{cursor:grab;user-select:none;touch-action:none}.p.arrastando .hd{cursor:grabbing}
    .atual{border:1px solid rgba(184,137,43,.55);background:#FFFBF1}
    .atual .rot{font-size:10px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:#8A6A22;margin-bottom:2px}
    .hd{display:flex;align-items:center;gap:8px;padding:10px 12px;background:#0B0B0C;color:#F4F3EF;flex-shrink:0}
    .hd img{width:18px;height:18px}.hd b{font-weight:800}
    .dev{font-size:10px;font-weight:800;color:#0B0B0C;background:#D4A84B;border-radius:5px;padding:1px 5px}
    .hd .eq{margin-left:auto;font-size:11px;color:#B9B7B0;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer}
    .hd button{background:none;border:0;color:#B9B7B0;cursor:pointer;font-size:14px;padding:0 0 0 6px}
    .tabs{display:flex;background:#0B0B0C;padding:0 6px 6px;gap:2px;flex-shrink:0}
    .tabs button{flex:1;min-width:0;background:none;border:0;border-radius:8px;color:#B9B7B0;font:600 11.5px inherit;font-family:inherit;padding:6px 2px;cursor:pointer}
    .tabs button.on{background:#F4F3EF;color:#0B0B0C}
    .tabs button:hover:not(.on){color:#fff}
    .bd{padding:12px;overflow-y:auto;overflow-x:hidden;flex:1;min-height:0}
    .st{border:1px solid rgba(11,11,12,.10);border-radius:12px;padding:10px 12px;margin-bottom:10px}
    .us{font-weight:700;font-size:14px;overflow-wrap:anywhere}.nm{color:#6E6E76;font-size:12px;margin-top:1px;overflow-wrap:anywhere}
    .chip{display:inline-flex;align-items:center;gap:6px;padding:2px 9px;border-radius:999px;font-weight:700;font-size:11.5px;background:color-mix(in srgb,var(--c) 14%,#fff);color:#0B0B0C;border:1px solid color-mix(in srgb,var(--c) 45%,#fff);white-space:nowrap}
    .chip i{width:8px;height:8px;border-radius:50%;background:var(--c)}
    .etp{position:relative;display:inline-flex;align-items:center;gap:1px;flex-shrink:0}
    .seta{border:0;background:none;cursor:pointer;font-size:12px;line-height:1;padding:4px 5px;border-radius:6px;color:#55555c}
    .seta:hover,.seta.on{background:#F0EEE9;color:#0B0B0C}
    .menu{position:fixed;z-index:5;background:#fff;border:1px solid rgba(11,11,12,.12);border-radius:10px;box-shadow:0 10px 24px rgba(11,11,12,.16);padding:4px;min-width:210px;white-space:nowrap;overflow-y:auto;box-sizing:border-box;visibility:hidden}
    .menu button{display:flex;align-items:center;gap:8px;width:100%;text-align:left;border:0;background:none;padding:7px 8px;border-radius:7px;font:inherit;font-size:12.5px;color:#0B0B0C;cursor:pointer}
    .menu button:hover:not(:disabled){background:#F6F3EA}
    .menu button:disabled{opacity:.5;cursor:default}
    .menu i{width:8px;height:8px;border-radius:50%;background:var(--c);flex-shrink:0}
    .menu small{margin-left:auto;color:#8a877f;font-size:10.5px}
    .st .chip{margin-top:8px}.st .etp{margin-top:8px}.st .etp .chip{margin-top:0}
    .nolead{margin-top:8px;font-size:12px;color:#6E6E76}
    .evs{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:10px}
    .ev{font-size:11px;padding:6px 8px;border-radius:9px;background:#F6F5F2;color:#6E6E76;min-width:0}
    .ev b{display:block;color:#0B0B0C;font-size:11.5px}
    .ev.ok{background:rgba(184,137,43,.12)}.ev.ok b{color:#8A6516}
    .acts{display:grid;grid-template-columns:1fr 1fr;gap:6px}
    .a{font:600 12.5px inherit;font-family:inherit;padding:9px 8px;border-radius:10px;border:1px solid rgba(11,11,12,.16);background:#fff;color:#0B0B0C;cursor:pointer;min-width:0;box-sizing:border-box;text-align:center;text-decoration:none;display:inline-block}
    .a:hover:not(:disabled){border-color:#B8892B}
    a.a.g{color:#fff}
    .a:disabled{opacity:.42;cursor:not-allowed}
    .a.g{background:#B8892B;border-color:#B8892B;color:#fff;font-weight:700}.a.g:hover:not(:disabled){background:#A87A20}
    .a.k{background:#0B0B0C;border-color:#0B0B0C;color:#fff}
    .a.s{padding:6px 9px;font-size:11.5px}
    .full{grid-column:1/-1;width:100%}
    label.chk{display:flex;align-items:center;gap:8px;font-size:12.5px;margin:2px 0 8px;cursor:pointer}
    label.chk input{accent-color:#B8892B;width:15px;height:15px}
    input.t,select.t,textarea.t{width:100%;box-sizing:border-box;font:13px inherit;font-family:inherit;padding:8px 10px;border-radius:10px;border:1px solid rgba(11,11,12,.18);background:#fff;color:#0B0B0C;margin-bottom:8px}
    textarea.t{min-height:64px;resize:vertical}
    input.t:focus,select.t:focus,textarea.t:focus{outline:2px solid rgba(184,137,43,.45);border-color:#B8892B}
    .msg{font-size:12px;margin:8px 0 0;padding:7px 9px;border-radius:9px;overflow-wrap:anywhere}
    .msg.e{background:#FDECEC;color:#8A1C1C}.msg.i{background:rgba(184,137,43,.12);color:#6B4F12}.msg.ok{background:#EAF7EF;color:#14532D}
    .msg .acts{margin-top:7px}
    .ft{display:flex;justify-content:space-between;gap:8px;padding:7px 12px;border-top:1px solid rgba(11,11,12,.08);font-size:10.5px;color:#8E8D86;flex-shrink:0}
    .ft span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ft a{color:#8E8D86;cursor:pointer;text-decoration:underline}
    .muted{color:#6E6E76;font-size:12px}
    .sec{font-size:10.5px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:#8E8D86;margin:12px 0 6px}
    .seg{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px}
    .seg button{font:600 11.5px inherit;font-family:inherit;padding:5px 10px;border-radius:999px;border:1px solid rgba(11,11,12,.16);background:#fff;cursor:pointer;color:#3A3A3F}
    .seg button.on{background:#0B0B0C;color:#fff;border-color:#0B0B0C}
    .kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
    .kpi{background:#F6F5F2;border-radius:10px;padding:8px}.kpi span{display:block;font-size:10.5px;color:#6E6E76}.kpi b{font-size:18px;font-weight:800}
    .kpi.g{background:rgba(184,137,43,.13)}
    .fun{display:grid;grid-template-columns:auto 1fr auto;gap:5px 8px;align-items:center;font-size:12px}
    .fun .bar{height:7px;border-radius:7px;background:#F0EEE9;overflow:hidden}.fun .bar i{display:block;height:100%;background:var(--c)}
    .item{border:1px solid rgba(11,11,12,.09);border-radius:11px;padding:8px 10px;margin-bottom:6px;min-width:0}
    .item.open{border-color:rgba(184,137,43,.6)}
    .item .l1{display:flex;align-items:flex-start;gap:8px;justify-content:space-between;cursor:pointer}
    .item .nm2{font-weight:700;font-size:12.5px;overflow-wrap:anywhere;min-width:0}
    .item .sub{font-size:11px;color:#6E6E76;overflow-wrap:anywhere}
    .item .det{margin-top:8px;padding-top:8px;border-top:1px dashed rgba(11,11,12,.12)}
    .row{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
    .tel{font-size:15px;font-weight:800;letter-spacing:.01em;margin:4px 0 6px;font-variant-numeric:tabular-nums}
    .crm{font-size:11px;font-weight:700;padding:2px 7px;border-radius:6px;background:#F0EEE9;color:#55555c;white-space:nowrap}
    .crm.ok{background:#EAF7EF;color:#14532D}.crm.e{background:#FDECEC;color:#8A1C1C}.crm.w{background:rgba(184,137,43,.15);color:#6B4F12}
    .presets{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:6px}.presets button{font:500 11px inherit;font-family:inherit;border:1px dashed rgba(184,137,43,.6);background:#fff;border-radius:999px;padding:3px 8px;cursor:pointer}
    .eqs button{display:block;width:100%;text-align:left;margin-bottom:6px}
    .mais{width:100%;margin-top:4px}
  </style><div class="p" id="p"></div>`;
  const P = raiz.getElementById('p');
  const $r = id => raiz.getElementById(id);

  // ── Teclado: nada digitado no painel chega ao Instagram ──
  // O Instagram tem atalhos de letra solta no document ("n", "b"…). Visto de fora da
  // Shadow DOM, o evento vem do HOST (um <div>), não do <input>, e o Instagram não o
  // reconhece como campo de texto: digitar "n" na busca abria o painel dele. Os eventos
  // param aqui, no topo da Shadow DOM, DEPOIS dos campos do painel (Enter etc. continuam).
  ['keydown', 'keyup', 'keypress', 'beforeinput', 'input'].forEach(t => raiz.addEventListener(t, e => e.stopPropagation()));

  // menu de etapas: fecha ao clicar fora dele ou com Esc
  P.addEventListener('click', e=>{ if(S.menuEtapa && !(e.target.closest&&e.target.closest('.menu,.seta'))){ S.menuEtapa=null; render(); } });
  raiz.addEventListener('keydown', e=>{ if(e.key==='Escape' && S.menuEtapa){ S.menuEtapa=null; render(); } });

  // ── Mover o painel: arrastar pelo cabeçalho; a posição fica guardada ──
  const POS = 'conalvo_pos';
  function colocar(x, y){
    const w=P.offsetWidth||360, h=P.offsetHeight||60;
    const nx=Math.min(Math.max(0, x), Math.max(0, window.innerWidth-w)), ny=Math.min(Math.max(0, y), Math.max(0, window.innerHeight-40));
    Object.assign(P.style, { left:nx+'px', top:ny+'px', right:'auto' }); return { x:nx, y:ny };
  }
  chrome.storage.local.get(POS).then(r=>{ const p=r&&r[POS]; if(p&&Number.isFinite(p.x)) colocar(p.x, p.y); }).catch(()=>{});
  window.addEventListener('resize', ()=>{ if(P.style.left) colocar(parseFloat(P.style.left), parseFloat(P.style.top)); });
  let arraste=null;
  P.addEventListener('pointerdown', e=>{
    const hd=e.target.closest&&e.target.closest('.hd'); if(!hd || e.button!==0 || e.target.closest('button,[data-a],input,select,a')) return;
    const r=P.getBoundingClientRect(); arraste={ dx:e.clientX-r.left, dy:e.clientY-r.top, id:e.pointerId };
    hd.setPointerCapture(e.pointerId); P.classList.add('arrastando'); e.preventDefault();
  });
  P.addEventListener('pointermove', e=>{ if(arraste&&e.pointerId===arraste.id) colocar(e.clientX-arraste.dx, e.clientY-arraste.dy); });
  const soltar = e=>{ if(!arraste||e.pointerId!==arraste.id) return; arraste=null; P.classList.remove('arrastando');
    chrome.storage.local.set({ [POS]:{ x:parseFloat(P.style.left)||0, y:parseFloat(P.style.top)||0 } }).catch(()=>{}); };
  P.addEventListener('pointerup', soltar); P.addEventListener('pointercancel', soltar);
  // dois cliques no cabeçalho: volta para o canto padrão
  P.addEventListener('dblclick', e=>{ if(!(e.target.closest&&e.target.closest('.hd')) || e.target.closest('button,[data-a]')) return;
    Object.assign(P.style, { left:'', top:'', right:'' }); chrome.storage.local.remove(POS).catch(()=>{}); });

  // ── Mensagens ──
  const aviso = (tipo, texto, acoes) => { S.msg = { tipo, texto, acoes:acoes||[] }; };
  const htmlMsg = () => { const m=S.msg; if(!m) return ''; return `<div class="msg ${m.tipo}">${esc(m.texto)}${m.acoes.length?`<div class="acts">${m.acoes.map(a=>`<button class="a s ${a.g?'g':''}" data-a="${a.a}" data-lead="${esc(a.lead||'')}">${esc(a.rotulo)}</button>`).join('')}</div>`:''}</div>`; };

  // ── Render ──
  function render(){
    if(S.minimizado){ P.className='p min'; P.innerHTML=`<div class="hd"><img src="${LOGO}" alt=""><b>Conalvo</b>${SELO}<button data-a="max" title="Abrir">▢</button></div>`; return ligar(); }
    P.className='p';
    const cab=`<div class="hd"><img src="${LOGO}" alt=""><b>Conalvo</b>${SELO}${S.equipe?`<span class="eq" data-a="trocar" title="Trocar de equipe">${esc(S.equipe.nome)}</span>`:''}<button data-a="min" title="Minimizar">–</button></div>`;
    const abas = S.usuario&&S.equipe ? `<div class="tabs">${[['perfil','Perfil'],['hoje','Hoje'],['leads','Leads'],['contatos','Contatos'],['config','Config']].map(([k,r])=>`<button class="${S.aba===k?'on':''}" data-a="aba" data-k="${k}">${r}</button>`).join('')}</div>` : '';
    let corpo;
    if(!S.usuario) corpo=telaLogin();
    else if(!S.equipe) corpo=telaEquipes();
    else corpo=({ perfil:telaPerfil, hoje:telaHoje, leads:telaLeads, contatos:telaContatos, config:telaConfig }[S.aba]||telaPerfil)();
    const t=S.tempos; const tempos=[t.consulta!=null?`consulta ${t.consulta} ms`:'', t.acao!=null?`ação ${t.acao} ms`:''].filter(Boolean).join(' · ');
    const rodape = S.usuario ? `<div class="ft"><span title="${esc(S.usuario.email)}">${esc(S.usuario.nome)}</span><span>${tempos}</span><a data-a="sair">Sair</a></div>` : '';
    const rolagem = (P.querySelector('.bd')||{}).scrollTop||0;
    // quem estava digitando continua digitando: sem isto, redesenhar (ex.: a busca filtrando)
    // tirava o foco do campo e as letras seguintes iam para o Instagram ("n", "b" abriam atalhos dele)
    const ativo = raiz.activeElement, foco = ativo && ativo.id && /^(INPUT|TEXTAREA|SELECT)$/.test(ativo.tagName)
      ? { id:ativo.id, ini:ativo.selectionStart, fim:ativo.selectionEnd } : null;
    P.innerHTML = cab + abas + `<div class="bd">${corpo}${htmlMsg()}</div>` + rodape;
    const bd=P.querySelector('.bd'); if(bd) bd.scrollTop=rolagem;
    ligar();
    posicionarMenu(); if(bd) bd.addEventListener('scroll', posicionarMenu, { passive:true });
    if(foco){ const el=$r(foco.id); if(el){ el.focus({ preventScroll:true }); try{ if(foco.ini!=null) el.setSelectionRange(foco.ini, foco.fim); }catch(e){} } }
  }
  // Menu de etapas: fica na TELA (position:fixed), não dentro da área do painel. Com a lista
  // curta (busca com 1 resultado) o painel encolhe e o menu ficava cortado, pedindo rolagem.
  // Abre para baixo da setinha; sem espaço, para cima; se nem assim cabe, rola só o menu.
  function posicionarMenu(){
    const mn=P.querySelector('.menu'), bt=mn&&mn.parentElement.querySelector('.seta'); if(!bt) return;
    const b=bt.getBoundingClientRect(), m=8, vw=window.innerWidth, vh=window.innerHeight;
    mn.style.maxHeight='none'; const h=mn.offsetHeight, w=mn.offsetWidth;
    const baixo=vh-b.bottom-4-m, cima=b.top-4-m, paraBaixo = h<=baixo || baixo>=cima, livre=Math.max(120, paraBaixo?baixo:cima);
    mn.style.maxHeight=livre+'px';
    mn.style.top=(paraBaixo ? b.bottom+4 : Math.max(m, b.top-4-Math.min(h, livre)))+'px';
    mn.style.left=Math.min(Math.max(m, b.right-w), Math.max(m, vw-w-m))+'px';
    mn.style.visibility='visible';
  }
  window.addEventListener('resize', posicionarMenu);
  function telaLogin(){
    return `<div class="muted" style="margin-bottom:8px">Entre com o e-mail e a senha da sua conta Conalvo (os mesmos do painel)${AMB === 'staging' ? ' · staging' : ''}.</div>
      <input class="t" id="email" type="email" placeholder="E-mail" autocomplete="username">
      <input class="t" id="senha" type="password" placeholder="Senha" autocomplete="current-password">
      <button class="a g full" data-a="entrar" ${S.ocupado?'disabled':''}>${S.ocupado==='entrar'?'Entrando…':'Entrar'}</button>`;
  }
  function telaEquipes(){
    if(S.equipes===null) return '<div class="muted">Carregando equipes…</div>';
    if(!S.equipes.length) return '<div class="muted">Sua conta não participa de nenhuma equipe ativa.</div>';
    return `<div class="muted" style="margin-bottom:8px">Escolha a equipe:</div><div class="eqs">${S.equipes.map(e=>`<button class="a" data-a="equipe" data-id="${esc(e.org_id)}" data-nome="${esc(e.org_name)}">${esc(e.org_name)}</button>`).join('')}</div>`;
  }
  const crmTexto = L => { const c=(L&&L.crm)||{}; if(!crmAtivo()||!L||!L.etapa||!L.etapa.contato) return ''; const m={ ok:['ok','No CRM ✓'], manual:['ok','Marcado: já está no CRM'], enviando:['w','Enviando ao CRM…'], falhou:['e','Falha no envio ao CRM'], incerto:['w','CRM sem resposta: conferir'] }; const [cls,txt]=m[c.estado]||['','Ainda não enviado ao CRM']; return `<span class="crm ${cls}">${txt}</span>`; };
  function acoesCRM(L){
    if(!crmAtivo()||!L||!L.etapa||!L.etapa.contato) return '';
    const e=(L.crm||{}).estado, b=(a,r,g)=>`<button class="a s ${g?'g':''}" data-a="${a}" data-lead="${esc(L.id)}" ${S.ocupado?'disabled':''}>${r}</button>`;
    if(e==='ok') return '';
    if(e==='manual') return `<div class="row">${b('crm_desmarcar','Desfazer "já está no CRM"')}</div>`;
    if(e==='incerto') return `<div class="row">${b('crm_marcar','Já está no CRM',true)}${b('crm_forcar','Reenviar mesmo assim')}</div>`;
    return `<div class="row">${b('crm_enviar', e==='falhou'?'Tentar enviar de novo':'Enviar ao CRM', true)}${b('crm_marcar','Já está no CRM')}</div>`;
  }
  function formTelefone(L){
    return `<div class="sec">Enviou contato</div><input class="t" id="tel" inputmode="tel" placeholder="(11) 99999-9999" value="${esc(S.telefone.valor||'')}">
      <div class="acts"><button class="a" data-a="tel_cancelar">Cancelar</button><button class="a g" data-a="tel_confirmar" data-lead="${esc(L.id)}" ${S.ocupado?'disabled':''}>${S.ocupado==='contato'?'Salvando…':'Confirmar contato'}</button></div>`;
  }
  function telaPerfil(){
    if(!S.perfil) return '<div class="muted">Abra o perfil de alguém no Instagram para ver o status e registrar ações.</div>';
    const L=S.lead, ev=(L&&L.eventos)||{};
    const chamado = ev.chamado ? `<b>${fmtDia(ev.chamado)}</b>` : (L&&L.chamado_legado ? '<b>registro antigo, sem data confiável</b>' : '<b>—</b>');
    const status = L===undefined ? '<div class="nolead">Consultando…</div>'
      : L===null ? '<div class="nolead">Ainda não é lead nesta equipe.</div>'
      : `${chipEtapa(L)} ${L.phone?`<div class="tel">${esc(fmtTel(L.phone))}</div>`:''}${crmTexto(L)}<div class="evs">
          <div class="ev ${ev.seguido?'ok':''}">Seguido<b>${ev.seguido?fmtDia(ev.seguido):'—'}</b></div>
          <div class="ev ${ev.chamado||L.chamado_legado?'ok':''}">Chamado${chamado}</div>
          <div class="ev ${ev.follow_up_hoje?'ok':''}">Follow-up<b>${ev.follow_up_hoje?'hoje ✓':(ev.ultimo_follow_up?'último '+fmtDia(ev.ultimo_follow_up):'—')}</b></div>
          <div class="ev ${ev.respondeu_hoje?'ok':''}">Respondeu<b>${ev.respondeu_hoje?'hoje ✓':'—'}</b></div></div>`;
    const feito = !!(ev.chamado||(L&&L.chamado_legado));
    let acoes='';
    if(L===null) acoes=`<label class="chk"><input type="checkbox" id="seguido" ${S.seguido?'checked':''}> Marcar como seguido</label>
          <button class="a g full" data-a="adicionar" ${S.ocupado?'disabled':''}>${S.ocupado==='adicionar'?'Adicionando…':'Adicionar lead'}</button>`;
    else if(L){
      const bt=(k,r,cls,off,tit)=>`<button class="a ${cls}" data-a="acao" data-k="${k}" ${S.ocupado||off?'disabled':''} title="${tit}">${S.ocupado===k?'Registrando…':r}</button>`;
      acoes=`<div class="acts">
          ${bt('chamado','Chamado','k',feito,feito?'Chamado já registrado':'Registrar o chamado agora')}
          ${bt('follow_up','Follow-up','g',!feito||ev.follow_up_hoje,!feito?'Registre o chamado antes':ev.follow_up_hoje?'Follow-up de hoje já registrado':'Registrar follow-up de hoje')}
          ${bt('respondeu','Respondeu','',!feito||ev.respondeu_hoje,!feito?'Registre o chamado antes':'Registrar que respondeu hoje')}
          ${bt('seguido','Seguido','',ev.seguido,ev.seguido?'Já marcado como seguido':'Marcar como seguido')}
          ${L.etapa&&L.etapa.contato?'':`<button class="a full" data-a="tel_abrir" data-lead="${esc(L.id)}" ${S.ocupado||!feito?'disabled':''} title="${feito?'Registrar o contato (telefone)':'Registre o chamado antes'}">Enviou contato</button>`}
        </div>${S.telefone&&S.telefone.leadId===L.id?formTelefone(L):''}<div style="margin-top:8px">${acoesCRM(L)}</div>`;
    }
    return `<div class="st"><div class="us">@${esc(S.perfil.username)}</div><div class="nm">${esc(S.perfil.name&&S.perfil.name!==S.perfil.username?S.perfil.name:'')}</div>${status}</div>${acoes}`;
  }
  function telaHoje(){
    const H=S.hoje, d=H.dados, ev=(d&&d.eventos)||{};
    const seg=`<div class="seg">${[['hoje','Hoje'],['7d','7 dias'],['mes','Mês']].map(([k,r])=>`<button class="${H.periodo===k?'on':''}" data-a="hoje_periodo" data-k="${k}">${r}</button>`).join('')}<span style="flex:1"></span>${[[false,'Equipe'],[true,'Só eu']].map(([v,r])=>`<button class="${H.meus===v?'on':''}" data-a="hoje_meus" data-k="${v}">${r}</button>`).join('')}</div>`;
    if(!d) return seg + '<div class="muted">Carregando…</div>';
    const ch=ev.chamado||0, resp=ev.respondeu||0;
    const k=(r,v,g)=>`<div class="kpi ${g?'g':''}"><span>${r}</span><b>${v}</b></div>`;
    const max=Math.max(1,...d.funil.map(f=>f.n));
    return seg + `<div class="kpis">${k('Adicionados',d.adicionados)}${k('Seguidos',ev.seguido||0)}${k('Chamados',ch,true)}${k('Follow-ups',ev.follow_up||0,true)}${k('Responderam',resp)}${k('Contatos',ev.contato||0,true)}</div>
      <div class="muted" style="margin-top:6px">Taxa de resposta: <b>${ch?Math.round(resp/ch*100):0}%</b>${d.incompleto?` · registro de ações desde ${esc(fmtData(d.registro_desde))}: o período começa antes disso`:''}</div>
      <div class="sec">Funil atual da equipe</div><div class="fun">${d.funil.map(f=>`${chip(f)}<div class="bar"><i style="--c:${esc(f.color)};width:${Math.round(f.n/max*100)}%"></i></div><b>${f.n.toLocaleString('pt-BR')}</b>`).join('')}</div>
      <div class="sec">Adicionados recentemente</div>${d.recentes.length?d.recentes.map(itemLead).join(''):'<div class="muted">Nenhum lead ainda.</div>'}`;
  }
  function itemLead(L){
    const aberto = S.aba==='leads' && S.leads.aberto===L.id;
    let det = !aberto && S.telefone && S.telefone.leadId===L.id ? `<div class="det">${formTelefone(L)}</div>` : '';
    if(aberto){
      const pl=pipelineDo(L), est=pl?[...pl.stages].sort((a,b)=>a.order-b.order):[];
      const notasEtapa=((est.find(e=>e.key===L.status)||{}).notes)||[];
      det=`<div class="det">
        <div class="row" style="margin-bottom:6px"><select class="t" id="etapa-${esc(L.id)}" style="margin:0;flex:1">${L.etapa&&L.etapa.contato?`<option value="" selected disabled>${esc(L.etapa.label)} (atual)</option>`:''}${est.filter(e=>e.key!==(pl&&pl.contato_key)).map(e=>`<option value="${esc(e.key)}" ${e.key===L.status?'selected':''}>${esc(e.label)}</option>`).join('')}</select><button class="a s" data-a="mudar_etapa" data-lead="${esc(L.id)}" ${S.ocupado?'disabled':''}>Mudar etapa</button></div>
        ${notasEtapa.length?`<div class="presets">${notasEtapa.map(n=>`<button data-a="preset" data-lead="${esc(L.id)}" data-txt="${esc(n)}">${esc(n)}</button>`).join('')}</div>`:''}
        <textarea class="t" id="nota-${esc(L.id)}" placeholder="Observação">${esc(L.notes||'')}</textarea>
        <div class="row" style="margin-bottom:6px"><button class="a s" data-a="salvar_nota" data-lead="${esc(L.id)}" ${S.ocupado?'disabled':''}>Salvar observação</button>
          ${L.etapa&&L.etapa.contato?'':`<button class="a s g" data-a="tel_abrir" data-lead="${esc(L.id)}">Enviou contato</button>`}
          <a class="a s" href="https://www.instagram.com/${esc(L.username)}/" target="_blank" rel="noopener">Abrir perfil</a></div>
        ${S.telefone&&S.telefone.leadId===L.id?formTelefone(L):''}
        ${acoesCRM(L)}
        <div class="row" style="margin-top:6px"><button class="a s" data-a="excluir" data-lead="${esc(L.id)}" style="color:#8A1C1C">${S.excluir===L.id?'Confirmar exclusão':'Excluir lead'}</button></div>
      </div>`;
    }
    return `<div class="item ${aberto?'open':''}"><div class="l1" data-a="abrir_lead" data-lead="${esc(L.id)}"><div style="min-width:0"><div class="nm2">${esc(L.name||('@'+L.username))}</div><div class="sub">@${esc(L.username)} · ${esc(fmtData(L.added_at))}${L.notes?' · 📝':''}</div></div>${chipEtapa(L)}</div>${det}</div>`;
  }
  // Perfil aberto no Instagram, no topo da aba Leads: status ou "Adicionar lead".
  function perfilNaLista(){
    if(!S.perfil) return '';
    const L=S.lead;
    const st = L===undefined ? '<div class="muted">Consultando…</div>' : L===null ? '<div class="nolead">Ainda não é lead nesta equipe.</div>' : `<div>${chipEtapa(L)}</div>`;
    const acao = L===null ? `<label class="chk"><input type="checkbox" id="seguido" ${S.seguido?'checked':''}> Marcar como seguido</label>
        <button class="a g full" data-a="adicionar" ${S.ocupado?'disabled':''}>${S.ocupado==='adicionar'?'Adicionando…':'Adicionar lead'}</button>`
      : L ? `<div class="row" style="margin-top:6px"><button class="a s" data-a="ver_perfil">Registrar ações</button></div>` : '';
    return `<div class="item atual" id="perfil-atual"><div class="rot">Perfil aberto</div><div class="nm2">${esc(S.perfil.name&&S.perfil.name!==S.perfil.username?S.perfil.name:'@'+S.perfil.username)}</div><div class="sub">@${esc(S.perfil.username)}</div>${st}${acao}</div>`;
  }
  function telaLeads(){
    const F=S.leads, est=etapasPadrao();
    const ordem=`<div class="seg">${[['recentes','Mais recentes'],['antigos','Mais antigos']].map(([k,r])=>`<button class="${F.ordem===k?'on':''}" data-a="leads_ordem" data-k="${k}" title="${k==='antigos'?'Começa pelos leads adicionados há mais tempo':'Começa pelos leads adicionados agora'}">${r}</button>`).join('')}</div>`;
    return `${perfilNaLista()}${ordem}<input class="t" id="l-busca" placeholder="Buscar por nome, @ ou telefone" value="${esc(F.busca)}">
      <div class="row" style="margin-bottom:8px"><select class="t" id="l-etapa" style="margin:0;flex:1"><option value="">Todas as etapas</option>${est.map(e=>`<option value="${esc(e.key)}" ${F.etapa===e.key?'selected':''}>${esc(e.label)}</option>`).join('')}</select>
        <label class="chk" style="margin:0"><input type="checkbox" id="l-meus" ${F.meus?'checked':''}> Só meus</label></div>
      <input class="t" id="l-nota" placeholder="Buscar nas observações" value="${esc(F.nota)}">
      ${F.itens.map(itemLead).join('')}
      ${F.carregando?'<div class="muted">Carregando…</div>':F.carregado&&!F.itens.length?'<div class="muted">Nenhum lead encontrado.</div>':''}
      ${F.proximo&&!F.carregando?'<button class="a mais" data-a="mais_leads">Carregar mais</button>':''}`;
  }
  function telaContatos(){
    const F=S.contatos;
    const card=L=>`<div class="item"><div class="row" style="justify-content:space-between;align-items:flex-start;flex-wrap:nowrap"><div style="min-width:0"><div class="nm2">${esc(L.name||('@'+L.username))}</div><div class="sub">@${esc(L.username)}</div></div>${crmTexto(L)}</div>
        <div class="tel">${esc(fmtTel(L.phone))}</div>
        <div class="acts"><button class="a s" data-a="copiar" data-txt="${esc(L.phone)}">Copiar número</button><a class="a s g" href="${esc(linkWhats(L.phone))}" target="_blank" rel="noopener">WhatsApp</a></div>
        ${acoesCRM(L)?`<div style="margin-top:6px">${acoesCRM(L)}</div>`:''}</div>`;
    return `<input class="t" id="c-busca" placeholder="Buscar contato por nome, @ ou telefone" value="${esc(F.busca)}">
      ${F.itens.map(card).join('')}
      ${F.carregando?'<div class="muted">Carregando…</div>':F.carregado&&!F.itens.length?'<div class="muted">Nenhum contato ainda.</div>':''}
      ${F.proximo&&!F.carregando?'<button class="a mais" data-a="mais_contatos">Carregar mais</button>':''}`;
  }
  function telaConfig(){
    const c=S.ctx; if(!c) return '<div class="muted">Carregando…</div>';
    const modo = c.org.module_id==='consorcio' ? 'Consórcio' : 'Prospecção';
    const destinos = c.pipelines.reduce((a,p)=>a+(p.crm_destinos||0),0);
    return `<div class="sec" style="margin-top:0">Conta</div><div class="st"><div class="us">${esc(S.usuario.nome)}</div><div class="nm">${esc(S.usuario.email)}</div></div>
      <div class="sec">Equipe</div><div class="st"><div class="us">${esc(c.org.name)}</div><div class="nm">${modo} · ${c.papel==='owner'?'dono':'membro'}</div><div style="margin-top:8px"><button class="a s" data-a="trocar">Trocar de equipe</button></div></div>
      <div class="sec">CRM externo</div><div class="st">${c.crm.ativo?`<span class="crm ok">Ativo</span> <span class="muted">${destinos} etapa(s) com destino configurado</span>`:`<span class="crm">Desativado</span><div class="nm" style="margin-top:4px">${esc(c.crm.motivo||'')}</div>`}</div>
      <div class="sec">Funis e etapas</div>${c.pipelines.map(p=>`<div class="st"><div class="us" style="font-size:12.5px">${esc(p.name)}${p.is_default?' · principal':''}</div><div class="row" style="margin-top:6px">${[...p.stages].sort((a,b)=>a.order-b.order).map(chip).join('')}</div></div>`).join('')}
      <div class="sec">Sobre</div><div class="muted">Conalvo 1.11${AMB === 'staging' ? ' · DEV (staging local)' : ''} · as cores das etapas vêm da configuração do funil da equipe.</div>`;
  }

  function ligar(){
    P.querySelectorAll('[data-a]').forEach(el=>{ el.onclick=ev=>{ ev.stopPropagation(); acaoUI(el.dataset.a, el); }; });
    const s=$r('seguido'); if(s) s.onchange=e=>{ S.seguido=e.target.checked; };
    const senha=$r('senha'); if(senha) senha.onkeydown=e=>{ if(e.key==='Enter') acaoUI('entrar'); };
    const tel=$r('tel'); if(tel){ tel.oninput=e=>{ S.telefone.valor=e.target.value; }; tel.onkeydown=e=>{ if(e.key==='Enter') acaoUI('tel_confirmar', { dataset:{ lead:S.telefone.leadId } }); }; }
    let tmr; const deb=(fn)=>{ clearTimeout(tmr); tmr=setTimeout(fn,300); };
    const lb=$r('l-busca'); if(lb) lb.oninput=e=>{ S.leads.busca=e.target.value; deb(()=>carregarLeads(true)); };
    const ln=$r('l-nota'); if(ln) ln.oninput=e=>{ S.leads.nota=e.target.value; deb(()=>carregarLeads(true)); };
    const le=$r('l-etapa'); if(le) le.onchange=e=>{ S.leads.etapa=e.target.value; carregarLeads(true); };
    const lm=$r('l-meus'); if(lm) lm.onchange=e=>{ S.leads.meus=e.target.checked; carregarLeads(true); };
    const cb=$r('c-busca'); if(cb) cb.oninput=e=>{ S.contatos.busca=e.target.value; deb(()=>carregarContatos(true)); };
  }
  const manterFoco = id => { const el=$r(id); if(el){ el.focus(); const v=el.value; el.setSelectionRange&&el.setSelectionRange(v.length,v.length); } };

  // ── Ações ──
  async function acaoUI(a, el){
    const lead = el && el.dataset && el.dataset.lead;
    if(!['abrir_lead','preset','hoje_periodo','hoje_meus'].includes(a)) S.msg=null;
    if(a!=='etapa_menu' && a!=='etapa_escolher') S.menuEtapa=null;
    switch(a){
      case 'min': S.minimizado=true; return render();
      case 'max': S.minimizado=false; return render();
      case 'entrar': return entrar();
      case 'sair': await enviar({ tipo:'sair' }); zerarEquipe(); Object.assign(S,{ usuario:null, equipe:null, equipes:null }); return render();
      case 'trocar': await enviar({ tipo:'escolher_equipe', equipe:null }); zerarEquipe(); S.equipe=null; return carregarEquipes();
      case 'equipe': return escolherEquipe({ id:el.dataset.id, nome:el.dataset.nome });
      case 'aba': S.aba=el.dataset.k; render(); return abrirAba();
      case 'adicionar': return adicionar();
      case 'etapa_menu': S.menuEtapa = S.menuEtapa===lead ? null : lead; return render();
      case 'etapa_escolher': {
        S.menuEtapa=null; const L=acharLead(lead), pl=pipelineDo(L), k=el.dataset.k;
        if(pl && k===pl.contato_key){ S.telefone={ leadId:lead, valor:(L&&L.phone)||'' }; render(); return manterFoco('tel'); }
        return mudarEtapa(lead, k);
      }
      case 'ver_perfil': S.aba='perfil'; return render();
      case 'acao': return registrar(el.dataset.k);
      case 'tel_abrir': { const L=acharLead(lead); S.telefone={ leadId:lead, valor:(L&&L.phone)||'' }; render(); return manterFoco('tel'); }
      case 'tel_cancelar': S.telefone=null; return render();
      case 'tel_confirmar': return enviarContato(lead, (S.telefone&&S.telefone.valor)||'');
      case 'crm_enviar': return enviarCRM(lead, false);
      case 'crm_forcar': return enviarCRM(lead, true);
      case 'crm_marcar': return crmManual(lead, true);
      case 'crm_desmarcar': return crmManual(lead, false);
      case 'hoje_periodo': S.hoje.periodo=el.dataset.k; return carregarHoje();
      case 'hoje_meus': S.hoje.meus=el.dataset.k==='true'; return carregarHoje();
      case 'abrir_lead': {
        if(S.aba!=='leads'){ const L=acharLead(lead); if(L){ S.aba='perfil'; location.href=`https://www.instagram.com/${L.username}/`; } return; }   // Hoje/recentes: abre o perfil
        S.leads.aberto = S.leads.aberto===lead ? null : lead; S.telefone=null; S.excluir=null; return render();
      }
      case 'leads_ordem': if(S.leads.ordem===el.dataset.k) return; S.leads.ordem=el.dataset.k; S.leads.aberto=null; S.leads.itens=[]; S.leads.carregado=false; return carregarLeads(true);
      case 'mais_leads': return carregarLeads(false);
      case 'mais_contatos': return carregarContatos(false);
      case 'mudar_etapa': { const v=$r('etapa-'+lead).value; if(!v){ aviso('i','Escolha a nova etapa.'); return render(); } return mudarEtapa(lead, v); }
      case 'preset': { const t=$r('nota-'+lead); t.value = (t.value? t.value.trimEnd()+'\n' : '') + el.dataset.txt; return; }
      case 'salvar_nota': return salvarNota(lead, $r('nota-'+lead).value);
      case 'excluir': if(S.excluir!==lead){ S.excluir=lead; return render(); } return excluir(lead);
      case 'copiar': try{ await navigator.clipboard.writeText(el.dataset.txt); aviso('ok','Número copiado.'); }catch(_){ aviso('e','Não foi possível copiar.'); } return render();
    }
  }
  function zerarEquipe(){ S.ctx=null; S.lead=undefined; S.telefone=null; S.excluir=null; S.hoje.dados=null; Object.assign(S.leads, vazioLista(), { aberto:null }); Object.assign(S.contatos, vazioLista()); for(const k in seq) seq[k]++; }
  async function entrar(){
    const email=$r('email').value, senha=$r('senha').value;
    S.ocupado='entrar'; render();
    const r=await enviar({ tipo:'entrar', email, senha }); S.ocupado='';
    if(!r.ok){ aviso('e', /invalid/i.test(r.erro)?'E-mail ou senha incorretos.':r.erro); return render(); }
    S.usuario=r.usuario; S.equipe=null; return carregarEquipes();
  }
  async function carregarEquipes(){
    S.equipes=null; render();
    try{ S.equipes=await rpc('ext2_my_orgs', {}); }catch(e){ S.equipes=[]; aviso('e', e.message); }
    if(S.equipes.length===1) return escolherEquipe({ id:S.equipes[0].org_id, nome:S.equipes[0].org_name });
    render();
  }
  async function escolherEquipe(eq){
    zerarEquipe(); S.equipe=eq; await enviar({ tipo:'escolher_equipe', equipe:eq }); render();
    const id=eq.id;
    try{ const c=await rpc('ext2_contexto', { p_org_id:id }); if(eqId()!==id) return; S.ctx=c; }catch(e){ if(eqId()===id) aviso('e', e.codigo==='acesso'?'Sem acesso a esta equipe.':e.message); }
    render(); consultar(); abrirAba();
  }
  function abrirAba(){
    if(S.aba==='hoje') return carregarHoje();
    if(S.aba==='leads' && !S.leads.carregado) return carregarLeads(true);
    if(S.aba==='contatos' && !S.contatos.carregado) return carregarContatos(true);
    if(S.aba==='leads') return carregarLeads(true, true);
    if(S.aba==='contatos') return carregarContatos(true, true);
  }
  const acharLead = id => (S.lead&&S.lead.id===id&&S.lead) || S.leads.itens.find(x=>x.id===id) || S.contatos.itens.find(x=>x.id===id) || ((S.hoje.dados&&S.hoje.dados.recentes)||[]).find(x=>x.id===id) || null;
  // Atualiza o mesmo lead em todas as telas (perfil, listas, recentes).
  function trocarLead(novo){
    if(!novo) return;
    if(S.lead&&S.lead.id===novo.id) S.lead=novo;
    for(const lista of [S.leads.itens, S.contatos.itens, (S.hoje.dados&&S.hoje.dados.recentes)||[]]){ const i=lista.findIndex(x=>x.id===novo.id); if(i>=0) lista[i]=novo; }
  }

  async function carregarHoje(){
    const id=eqId(); if(!id) return; const n=++seq.hoje;
    const hoje=diaBR(), de = S.hoje.periodo==='hoje' ? hoje : S.hoje.periodo==='7d' ? diaBR(new Date(Date.now()-6*86400000)) : hoje.slice(0,8)+'01';
    S.hoje.carregando=true; render(); const t0=performance.now();
    try{ const d=await rpc('ext2_resumo', { p_org_id:id, p_de:de, p_ate:hoje, p_so_meus:S.hoje.meus }); if(n!==seq.hoje||eqId()!==id) return; S.hoje.dados=d; S.tempos.consulta=Math.round(performance.now()-t0); }
    catch(e){ if(n===seq.hoje) aviso('e', e.message); }
    S.hoje.carregando=false; render();
  }
  async function carregarPagina(estado, chave, reiniciar, filtros, foco){
    const id=eqId(); if(!id) return; const n=++seq[chave];
    if(reiniciar){ estado.proximo=null; }
    estado.carregando=true; if(reiniciar&&!foco) estado.itens = estado.carregado ? estado.itens : []; render(); if(foco) manterFoco(foco);
    const t0=performance.now();
    try{
      const r=await rpc('ext2_listar_leads', { p_org_id:id, ...filtros, p_limite:25, p_cursor_data:reiniciar?null:(estado.proximo&&estado.proximo.data), p_cursor_id:reiniciar?null:(estado.proximo&&estado.proximo.id) });
      if(n!==seq[chave]||eqId()!==id) return;                           // trocou de equipe/filtro no meio: descarta
      estado.itens = reiniciar ? r.itens : estado.itens.concat(r.itens); estado.proximo=r.proximo; estado.carregado=true;
      S.tempos.consulta=Math.round(performance.now()-t0);
    }catch(e){
      if(n!==seq[chave]) return;
      // banco sem a X-03: a função não conhece p_ordem. Volta para "mais recentes" com um aviso claro.
      if(filtros.p_ordem && /p_ordem|ext2_listar_leads|schema cache|does not exist/i.test(e.message)){ S.leads.ordem='recentes'; estado.carregando=false; aviso('i','"Mais antigos" ainda não está disponível nesta equipe: falta uma atualização do banco. Mostrando os mais recentes.'); return carregarLeads(true); }
      aviso('e', e.message);
    }
    if(n===seq[chave]){ estado.carregando=false; render(); if(foco) manterFoco(foco); }
  }
  const focoAtivo = () => { const a=raiz.activeElement; return a&&a.id&&/^(l-busca|l-nota|c-busca)$/.test(a.id)?a.id:null; };
  const carregarLeads = (reiniciar) => { const F=S.leads; return carregarPagina(F, 'leads', reiniciar, { p_busca:F.busca||null, p_etapa:F.etapa||null, p_nota:F.nota||null, p_so_meus:F.meus, p_so_contatos:false, ...(F.ordem==='antigos'?{ p_ordem:'antigos' }:{}) }, focoAtivo()); };
  const carregarContatos = (reiniciar) => { const F=S.contatos; return carregarPagina(F, 'contatos', reiniciar, { p_busca:F.busca||null, p_so_contatos:true }, focoAtivo()); };

  async function consultar(){
    if(!S.equipe||!S.perfil) return render();
    const n=++seq.perfil, alvo=S.perfil.username, id=eqId();
    S.lead=undefined; render(); const t0=performance.now();
    try{
      const r=await rpc('ext2_lead_status', { p_org_id:id, p_username:alvo });
      if(n!==seq.perfil||eqId()!==id) return;
      S.lead=r; S.tempos.consulta=Math.round(performance.now()-t0);
      corrigirNome();
    }catch(e){ if(n!==seq.perfil) return; S.lead=null; aviso('e', e.codigo==='acesso'?'Sem acesso a esta equipe.':e.message); if(e.codigo==='login') S.usuario=null; }
    render();
  }
  // Nome salvo igual ao @ (ou vazio) e o perfil mostra o nome real: corrige (como a 1.10.4).
  async function corrigirNome(){
    const L=S.lead, p=S.perfil; if(!L||!p) return;
    const nome=findRealName(p.username); if(!nome||nome===p.username) return;
    const atual=(L.name||'').trim(); if(atual && atual.toLowerCase()!==p.username && !isBadName(atual)) return;
    try{ await rpc('ext2_update_lead', { p_org_id:eqId(), p_ext_id:L.ext_id||L.id, p_name:nome }); L.name=nome; }catch(_){}
  }
  async function executar(rotulo, fn){
    S.ocupado=rotulo; render(); const t0=performance.now();
    try{ const r=await fn(); S.tempos.acao=Math.round(performance.now()-t0); return r; }
    catch(e){ aviso('e', e.codigo==='rede'?'Sem resposta do servidor. Nada foi confirmado; tente de novo (não duplica).':e.message); return null; }
    finally{ S.ocupado=''; render(); }
  }
  async function adicionar(){
    if(!S.perfil||!S.equipe) return; const id=eqId();
    const nome=findRealName(S.perfil.username); S.perfil.name=nome;
    const r=await executar('adicionar', ()=>rpcSeguro('ext2_adicionar_lead', { p_org_id:id, p_client_id:novoId(), p_username:S.perfil.username, p_name:nome!==S.perfil.username?nome:null, p_seguido:S.seguido }));
    if(!r||eqId()!==id) return render();
    S.lead=r.lead; aviso('ok', r.novo?(S.seguido?'Lead adicionado e marcado como seguido.':'Lead adicionado.'):'Este @ já era lead da equipe.'); S.leads.carregado=false; render();
    if(S.aba==='leads') carregarLeads(true);   // adicionado pela aba Leads: a lista já mostra o novo lead
  }
  async function registrar(kind){
    const L=S.lead; if(!L) return; const id=eqId();
    const r=await executar(kind, ()=>rpcSeguro('ext2_registrar_acao', { p_org_id:id, p_client_id:novoId(), p_lead_id:L.id, p_kind:kind }));
    if(!r||eqId()!==id) return render();
    trocarLead(r.lead); const nomes={ chamado:'Chamado', follow_up:'Follow-up', respondeu:'Respondeu', seguido:'Seguido' };
    aviso(r.registrado?'ok':'i', r.registrado?`${nomes[kind]} registrado.`:`${nomes[kind]} já estava registrado${kind==='chamado'||kind==='seguido'?'':' hoje'}.`); render();
  }
  async function mudarEtapa(leadId, etapa){
    const id=eqId();
    const r=await executar('etapa', ()=>rpcSeguro('ext2_mudar_etapa', { p_org_id:id, p_client_id:novoId(), p_lead_id:leadId, p_etapa:etapa }));
    if(!r||eqId()!==id) return render(); trocarLead(r.lead); aviso('ok', r.registrado?'Etapa alterada.':'O lead já estava nessa etapa.'); render();
  }
  async function salvarNota(leadId, texto){
    const id=eqId(); const r=await executar('nota', ()=>rpcSeguro('ext2_salvar_nota', { p_org_id:id, p_lead_id:leadId, p_notas:texto }));
    if(!r||eqId()!==id) return render(); trocarLead(r); aviso('ok','Observação salva.'); render();
  }
  async function excluir(leadId){
    const id=eqId(); const L=acharLead(leadId);
    const r=await executar('excluir', ()=>rpcSeguro('ext2_delete_lead', { p_org_id:id, p_ext_id:(L&&L.ext_id)||leadId }));
    S.excluir=null; if(r===null||eqId()!==id) return render();
    S.leads.itens=S.leads.itens.filter(x=>x.id!==leadId); S.contatos.itens=S.contatos.itens.filter(x=>x.id!==leadId); if(S.lead&&S.lead.id===leadId) S.lead=null;
    aviso('ok','Lead excluído.'); render();
  }
  // "Enviou contato": só mostra sucesso depois de o banco confirmar; o envio ao CRM vem em seguida.
  async function enviarContato(leadId, tel){
    const id=eqId();
    const r=await executar('contato', ()=>rpcSeguro('ext2_enviar_contato', { p_org_id:id, p_client_id:novoId(), p_lead_id:leadId, p_telefone:tel }));
    if(!r||eqId()!==id) return render();
    S.telefone=null; trocarLead(r.lead); S.contatos.carregado=false;
    aviso('ok', r.registrado?'Contato salvo no sistema.':'Este contato já estava registrado.'); render();
    if(r.crm_ativo) return enviarCRM(leadId, false);
    if(S.ctx&&S.ctx.org.module_id==='consorcio'&&S.ctx.crm&&!S.ctx.crm.ativo){ aviso('i', 'Contato salvo. CRM não enviado: '+(S.ctx.crm.motivo||'integração desativada.')); render(); }
  }
  async function enviarCRM(leadId, forcar){
    const id=eqId(); S.ocupado='crm'; render(); const t0=performance.now();
    try{
      const res=await rpcSeguro('ext2_crm_reservar', { p_org_id:id, p_lead_id:leadId, p_forcar:!!forcar });
      if(eqId()!==id) return;
      const txt={ ja_enviado:['ok','Este contato já está no CRM.'], em_andamento:['i','Envio ao CRM em andamento (outro clique ou aparelho). Aguarde.'], sem_mapeamento:['i','Contato salvo. A etapa não tem destino no CRM: não enviado (mesma regra do painel).'],
        sem_telefone:['e','Lead sem telefone.'], inativo:['i','CRM desativado nesta equipe.'] };
      if(res.acao==='incerto'){ aviso('i','O CRM não respondeu da última vez. Confira no CRM se o contato chegou antes de reenviar.', [{a:'crm_marcar',rotulo:'Já está no CRM',g:true,lead:leadId},{a:'crm_forcar',rotulo:'Reenviar mesmo assim',lead:leadId}]); return; }
      if(res.acao!=='enviar'){ const [tp,t]=txt[res.acao]||['i',res.acao]; aviso(tp,t); return; }
      const envio=await enviar({ tipo:'crm_enviar', envio:{ token:res.token, mapa:res.mapa, origem:res.origem, lead:res.lead } });
      const c=envio.ok ? envio.crm : { ok:false, incerto:true, erro:envio.erro };
      if(c.ok){
        const novo=await rpcSeguro('ext2_crm_concluir', { p_org_id:id, p_lead_id:leadId, p_reserva:res.reserva, p_person_id:c.personId, p_deal_id:c.dealId, p_funil:res.mapa.funnelName||'' });
        trocarLead(novo); S.tempos.acao=Math.round(performance.now()-t0);
        aviso('ok', c.dealId?`Enviado ao CRM ✓ (funil ${res.mapa.funnelName||''}).`:'Pessoa criada no CRM ✓ (negócio por conferir).');
      } else {
        const novo=await rpcSeguro('ext2_crm_falhou', { p_org_id:id, p_lead_id:leadId, p_reserva:res.reserva, p_erro:c.erro, p_incerto:!!c.incerto });
        trocarLead(novo);
        if(c.incerto) aviso('i','O CRM não respondeu. Confira no CRM se o contato chegou antes de reenviar.', [{a:'crm_marcar',rotulo:'Já está no CRM',g:true,lead:leadId},{a:'crm_forcar',rotulo:'Reenviar mesmo assim',lead:leadId}]);
        else aviso('e', c.erro+'. Nada foi criado no CRM.', [{a:'crm_enviar',rotulo:'Tentar de novo',g:true,lead:leadId}]);
      }
    }catch(e){ aviso('e', e.message); }
    finally{ S.ocupado=''; render(); }
  }
  async function crmManual(leadId, marcar){
    const id=eqId(); const r=await executar('crm', ()=>rpcSeguro('ext2_crm_manual', { p_org_id:id, p_lead_id:leadId, p_manual:marcar }));
    if(!r||eqId()!==id) return render(); trocarLead(r); aviso('ok', marcar?'Marcado: já está no CRM.':'Marcação desfeita.'); render();
  }

  // ── Perfil aberto (SPA: acompanha a URL) ──
  function verificarUrl(){
    if(location.href===S.href) return;
    S.href=location.href; S.msg=null; S.telefone=null;
    const u=perfilDaUrl(location.href);
    if(!u){ S.perfil=null; S.lead=undefined; seq.perfil++; return render(); }
    S.perfil={ username:u.toLowerCase(), name:u, url:location.href };
    let tent=0; const nome=()=>{ if(!S.perfil||S.perfil.username!==u.toLowerCase()) return; const n=findRealName(u); S.perfil.name=n; if(S.aba==='perfil'||S.aba==='leads') render(); if(n===u&&tent++<5) setTimeout(nome,700); };
    setTimeout(nome,600);
    consultar();
  }

  (async () => {
    document.documentElement.appendChild(host);
    const r=await enviar({ tipo:'estado' });
    S.usuario=r.ok?r.usuario:null;
    render();
    if(S.usuario){ if(r.equipe) escolherEquipe(r.equipe); else carregarEquipes(); }
    setInterval(verificarUrl, 400); window.addEventListener('popstate', verificarUrl); verificarUrl();
  })();
})();
