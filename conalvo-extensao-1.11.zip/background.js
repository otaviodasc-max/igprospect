// Conalvo 1.11 — service worker: login, sessão e chamadas ao banco.
// O mesmo código serve aos dois ambientes; quem decide é o config.js:
//   • staging  (extension-dev/config.js, gerado por dev/staging/semear.js): só 127.0.0.1;
//   • producao (montado por dev/extensao/montar-1.11.js): só o Supabase de
//     produção e o CRM de sempre (hubcorretorconsorcio.com.br), e só com a
//     chave PÚBLICA anônima — qualquer outra chave é recusada.
// (manifest: host_permissions de cada ambiente.)
// host_permissions do manifest). Sem "quem é você": o responsável de cada
// ação é o usuário logado (auth.uid() no banco).
importScripts('config.js');
const CFG = self.CONALVO_CFG || {};
const K = { sessao: 'cdev_sessao', equipe: 'cdev_equipe' };
// Só estas RPCs podem ser pedidas pelo content script.
const RPCS = new Set(['ext2_my_orgs', 'ext2_contexto', 'ext2_lead_status', 'ext2_adicionar_lead', 'ext2_registrar_acao',
  'ext2_resumo', 'ext2_listar_leads', 'ext2_mudar_etapa', 'ext2_salvar_nota', 'ext2_update_lead', 'ext2_delete_lead',
  'ext2_enviar_contato', 'ext2_crm_reservar', 'ext2_crm_concluir', 'ext2_crm_falhou', 'ext2_crm_manual']);
// Configuração válida só nestes dois formatos; qualquer outra é recusada.
(function validarConfig() {
  const papel = (() => { try { return JSON.parse(atob(String(CFG.SUPABASE_ANON_KEY).split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).role; } catch (e) { return null; } })();
  if (papel !== 'anon') throw new Error('Conalvo: config.js precisa da chave pública anônima (nunca uma chave privilegiada)');
  const local = /^http:\/\/127\.0\.0\.1:\d+$/;
  if (CFG.AMBIENTE === 'staging' && local.test(CFG.SUPABASE_URL || '') && local.test(CFG.CRM_BASE || '')) return;
  if (CFG.AMBIENTE === 'producao' && /^https:\/\/[a-z0-9]+\.supabase\.co$/.test(CFG.SUPABASE_URL || '') && CFG.CRM_BASE === 'https://hubcorretorconsorcio.com.br/api/agendor/v3') return;
  throw new Error('Conalvo: config.js inválido (staging = 127.0.0.1; produção = Supabase do projeto + CRM)');
})();

const ler = async k => (await chrome.storage.local.get(k))[k] || null;
const gravar = (k, v) => chrome.storage.local.set({ [k]: v });

async function auth(caminho, corpo) {
  const r = await fetch(`${CFG.SUPABASE_URL}/auth/v1/${caminho}`, { method: 'POST', headers: { apikey: CFG.SUPABASE_ANON_KEY, 'Content-Type': 'application/json' }, body: JSON.stringify(corpo) });
  const j = await r.json().catch(() => null);
  if (!r.ok) throw new Error((j && (j.error_description || j.msg || j.message)) || `Erro ${r.status}`);
  return j;
}
const paraSessao = j => ({ access: j.access_token, refresh: j.refresh_token, expira: Date.now() + (j.expires_in || 3600) * 1000,
  usuario: { id: j.user.id, email: j.user.email, nome: (j.user.user_metadata && j.user.user_metadata.full_name) || j.user.email } });

let renovando = null;   // uma renovação por vez, mesmo com várias abas
async function tokenValido() {
  let s = await ler(K.sessao);
  if (!s) return null;
  if (s.expira - Date.now() > 60000) return s.access;
  renovando = renovando || (async () => {
    try { s = paraSessao(await auth('token?grant_type=refresh_token', { refresh_token: s.refresh })); await gravar(K.sessao, s); return s.access; }
    catch (e) { await chrome.storage.local.remove([K.sessao, K.equipe]); return null; }
    finally { setTimeout(() => { renovando = null; }, 0); }
  })();
  return renovando;
}

async function rpc(fn, args, prazo = 8000) {
  if (!RPCS.has(fn)) throw new Error('Chamada não permitida');
  const tk = await tokenValido();
  if (!tk) { const e = new Error('Faça login'); e.codigo = 'login'; throw e; }
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), prazo);
  try {
    const r = await fetch(`${CFG.SUPABASE_URL}/rest/v1/rpc/${fn}`, { method: 'POST', signal: ctl.signal,
      headers: { apikey: CFG.SUPABASE_ANON_KEY, Authorization: `Bearer ${tk}`, 'Content-Type': 'application/json' }, body: JSON.stringify(args || {}) });
    const txt = await r.text(); const j = txt ? JSON.parse(txt) : null;
    if (r.status === 401) { await chrome.storage.local.remove([K.sessao]); const e = new Error('Sessão expirada. Entre de novo.'); e.codigo = 'login'; throw e; }
    if (!r.ok) { const e = new Error((j && j.message) || `Erro ${r.status}`); e.codigo = r.status === 403 ? 'acesso' : 'servidor'; throw e; }
    return j;
  } catch (e) {
    if (e.name === 'AbortError') { const x = new Error('Sem resposta do servidor'); x.codigo = 'rede'; throw x; }
    if (e instanceof TypeError) { const x = new Error('Sem conexão com o servidor'); x.codigo = 'rede'; throw x; }
    throw e;
  } finally { clearTimeout(t); }
}

// ── Envio ao CRM (mesmas rotas e regras da 1.10.4: pessoa com origem; negócio
// na etapa mapeada, com rotas alternativas e o PUT de reforço). Resultado:
//   ok      → pessoa criada (personId) e, se deu, o negócio (dealId)
//   incerto → sem resposta: o CRM PODE ter criado a pessoa — não reenviar sozinho
//   senão   → o CRM respondeu com erro: nada foi criado
async function crmReq(caminho, metodo, token, corpo) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), CFG.CRM_TIMEOUT_MS || 15000);
  try {
    const r = await fetch(`${CFG.CRM_BASE}${caminho}`, { method: metodo, signal: ctl.signal, headers: { Authorization: `Token ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(corpo) });
    return { r, j: await r.json().catch(() => ({})) };
  } finally { clearTimeout(t); }
}
async function crmEnviar({ token, mapa, origem, lead }) {
  const nm = (lead.name || '').trim(), un = (lead.username || '').trim().replace(/^@/, '');
  const nomePessoa = nm && un && nm.toLowerCase() !== un.toLowerCase() ? `${nm} (@${un})` : (nm || (un ? `@${un}` : 'Lead Conalvo'));
  const titulo = nm || (un ? `@${un}` : 'Lead Conalvo');
  const o = origem && (origem.id != null || (origem.name || '').trim()) ? origem : null;
  const origemNome = (o && o.name) || 'Redes sociais';
  const origemValor = o ? (o.id != null ? o.id : (o.name || '').trim() || null) : null;
  const origemCampo = (o && o.field) || 'origin';
  let pessoa;
  try {
    pessoa = await crmReq('/people', 'POST', token, {
      name: nomePessoa, contact: { mobile: lead.phone || '', instagram: un },
      ...(origemValor != null ? { [origemCampo]: origemValor } : {}),
      description: [lead.niche ? `Nicho: ${lead.niche}` : '', lead.notes ? `Obs: ${lead.notes}` : '', un ? `Perfil: https://www.instagram.com/${un}/` : '', `Origem: ${origemNome}`].filter(Boolean).join('\n'),
    });
  } catch (e) { return { ok: false, incerto: true, erro: 'O CRM não respondeu' }; }
  if (!pessoa.r.ok) return { ok: false, incerto: false, erro: `O CRM recusou (status ${pessoa.r.status})` };
  const personId = (pessoa.j && pessoa.j.data && pessoa.j.data.id) || pessoa.j.id;
  if (!personId) return { ok: false, incerto: true, erro: 'O CRM respondeu sem o id da pessoa' };
  let dealId = null;
  try {
    const corpo = { title: titulo, description: `Origem: ${origemNome}\nEnviado pela Conalvo (funil ${mapa.funnelName || ''}).`, dealStageId: mapa.stageId, funnelId: mapa.funnelId };
    const patch = origemValor != null ? { [origemCampo]: origemValor } : {};
    let d = await crmReq('/deals', 'POST', token, { ...corpo, ...patch, personId });
    if (o && (d.r.status === 400 || d.r.status === 422)) d = await crmReq('/deals', 'POST', token, { ...corpo, personId });
    if (d.r.status === 404 || d.r.status === 405) d = await crmReq(`/people/${personId}/deals`, 'POST', token, { title: titulo, description: corpo.description, dealStage: mapa.stageOrder, funnel: mapa.funnelId, ...patch });
    dealId = (d.j && d.j.data && d.j.data.id) || d.j.id || null;
    if (dealId) { try { await crmReq(`/deals/${dealId}`, 'PUT', token, { dealStageId: mapa.stageId, funnelId: mapa.funnelId, ...patch }); } catch (e) { /* etapa por conferir */ } }
  } catch (e) { /* pessoa criada; negócio por conferir — mesmo comportamento da 1.10.4 */ }
  return { ok: true, personId: String(personId), dealId: dealId ? String(dealId) : null };
}

chrome.runtime.onMessage.addListener((msg, _remetente, responder) => {
  (async () => {
    switch (msg && msg.tipo) {
      case 'entrar': {
        const s = paraSessao(await auth('token?grant_type=password', { email: String(msg.email || '').trim(), password: String(msg.senha || '') }));
        await gravar(K.sessao, s); await chrome.storage.local.remove(K.equipe);
        return { usuario: s.usuario };
      }
      case 'sair': {
        const s = await ler(K.sessao);
        await chrome.storage.local.remove([K.sessao, K.equipe]);
        if (s) fetch(`${CFG.SUPABASE_URL}/auth/v1/logout`, { method: 'POST', headers: { apikey: CFG.SUPABASE_ANON_KEY, Authorization: `Bearer ${s.access}` } }).catch(() => {});
        return {};
      }
      case 'estado': {
        const s = await ler(K.sessao);
        return { usuario: s ? s.usuario : null, equipe: s ? await ler(K.equipe) : null };
      }
      case 'escolher_equipe': { await gravar(K.equipe, msg.equipe || null); return {}; }
      case 'rpc': return { dados: await rpc(msg.fn, msg.args) };
      case 'crm_enviar': return { crm: await crmEnviar(msg.envio) };
      default: throw new Error('Mensagem desconhecida');
    }
  })().then(d => responder({ ok: true, ...d }), e => responder({ ok: false, erro: e.message, codigo: e.codigo || 'erro' }));
  return true;
});
