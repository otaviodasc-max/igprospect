// Conalvo 1.11 — PRODUÇÃO. Gerado por dev/extensao/montar-1.11.js a partir do config.js do painel.
// Só a chave PÚBLICA anônima (a mesma que o site publica); a proteção real é o RLS e o login.
self.CONALVO_CFG = { AMBIENTE: 'producao', SUPABASE_URL: 'https://guuecwrhwuzbwfetehix.supabase.co', SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd1dWVjd3Jod3V6YndmZXRlaGl4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE1NzA2NjAsImV4cCI6MjA5NzE0NjY2MH0.GISYZrdloR5GGezNwMUMKsdVG5E5VstnXeeAxsNqtOY', CRM_BASE: 'https://hubcorretorconsorcio.com.br/api/agendor/v3' };
